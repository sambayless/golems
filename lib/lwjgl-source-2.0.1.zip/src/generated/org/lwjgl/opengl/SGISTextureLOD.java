/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class SGISTextureLOD {
	/**
	 * Accepted by the &lt;pname&gt; parameter of TexParameteri, TexParameterf,
	 * TexParameteriv, TexParameterfv, GetTexParameteriv, and GetTexParameterfv.
	 */
	public static final int GL_TEXTURE_MIN_LOD_SGIS = 0x813a;
	public static final int GL_TEXTURE_MAX_LOD_SGIS = 0x813b;
	public static final int GL_TEXTURE_BASE_LEVEL_SGIS = 0x813c;
	public static final int GL_TEXTURE_MAX_LEVEL_SGIS = 0x813d;

	private SGISTextureLOD() {
	}

}
