/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class NVTextureEnvCombine4 {
	public static final int GL_COMBINE4_NV = 0x8503;
	public static final int GL_SOURCE3_RGB_NV = 0x8583;
	public static final int GL_SOURCE3_ALPHA_NV = 0x858b;
	public static final int GL_OPERAND3_RGB_NV = 0x8593;
	public static final int GL_OPERAND3_ALPHA_NV = 0x859b;

	private NVTextureEnvCombine4() {
	}

}
